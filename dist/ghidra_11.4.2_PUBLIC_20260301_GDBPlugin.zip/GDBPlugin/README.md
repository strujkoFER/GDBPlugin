GDB plugin for Ghidra
