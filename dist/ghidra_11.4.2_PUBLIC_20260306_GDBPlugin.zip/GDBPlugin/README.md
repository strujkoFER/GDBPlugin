GDB plugin for Ghidra
